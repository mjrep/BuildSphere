const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');
const initDeadlineJob = require('./jobs/deadlineChecker');

// Load environment variables
dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Initialize Cron Jobs
initDeadlineJob();

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(cookieParser());

// Routes
const authController = require('./controllers/AuthController');
const projectController = require('./controllers/ProjectController');
const dashboardController = require('./controllers/DashboardController');
const profileController = require('./controllers/ProfileController');
const clientController = require('./controllers/ClientController');
const projectApprovalController = require('./controllers/ProjectApprovalController');
const projectInventoryController = require('./controllers/ProjectInventoryController');
const taskController = require('./controllers/TaskController');
const taskCommentController = require('./controllers/TaskCommentController');
const { TaskAttachmentController, uploadMiddleware } = require('./controllers/TaskAttachmentController');
const { TaskProgressLogController, progressUploadMiddleware } = require('./controllers/TaskProgressLogController');
const ReportController = require('./controllers/ReportController');
const NotificationController = require('./controllers/NotificationController');
const AdminUserController = require('./controllers/AdminUserController');
const { ProjectFileController, projectFileUploadMiddleware } = require('./controllers/ProjectFileController');

const authenticateToken = require('./middleware/auth');
const projectLock = require('./middleware/projectLock');

// Auth Routes
app.post('/api/login', authController.login);
// app.post('/api/register', authController.register); // Public registration disabled
app.post('/api/logout', authController.logout);
app.post('/api/forgot-password', authController.forgotPassword);
app.get('/api/users', authenticateToken, authController.index);

// Admin Personnel Management
app.get('/api/admin/users', authenticateToken, AdminUserController.index);
app.post('/api/admin/users/invite', authenticateToken, AdminUserController.invite);
app.patch('/api/admin/users/:id/status', authenticateToken, AdminUserController.toggleStatus);
app.patch('/api/admin/users/:id/role', authenticateToken, AdminUserController.updateRole);
app.patch('/api/admin/users/:id', authenticateToken, AdminUserController.updateUser);

// Protected Core Routes
app.get('/api/dashboard/stats', authenticateToken, dashboardController.stats);
app.get('/api/auth/user', authenticateToken, profileController.show);
app.get('/api/profile/me', authenticateToken, profileController.show);
app.put('/api/profile/update', authenticateToken, profileController.update);

// Notification Routes
app.get('/api/notifications', authenticateToken, NotificationController.index);
app.patch('/api/notifications/read-all', authenticateToken, NotificationController.markAllAsRead);
app.patch('/api/notifications/:id/read', authenticateToken, NotificationController.markAsRead);

// Client Routes
app.get('/api/clients', authenticateToken, clientController.index);
app.post('/api/clients', authenticateToken, clientController.store);

// Project Routes
app.get('/api/project-statuses', authenticateToken, projectController.statuses);
app.get('/api/projects', authenticateToken, projectController.index);
app.post('/api/projects', authenticateToken, projectController.store);
app.get('/api/projects/statuses', authenticateToken, projectController.statuses);
app.get('/api/projects/phase-titles', authenticateToken, projectController.phaseTitles);
app.get('/api/projects/:id', authenticateToken, projectController.show);
app.get('/api/projects/:id/evm-data', authenticateToken, projectController.getEvmData);
app.get('/api/projects/:id/ai-assessment', authenticateToken, projectController.getAiAssessment);
app.put('/api/projects/:id', authenticateToken, projectLock('id'), projectController.update);
app.patch('/api/projects/:id/complete', authenticateToken, projectController.complete);
app.delete('/api/projects/:id', authenticateToken, projectLock('id'), projectController.destroy);
app.post('/api/projects/:id/team', authenticateToken, projectLock('id'), projectController.addTeamMember);
app.delete('/api/projects/:id/team/:userId', authenticateToken, projectLock('id'), projectController.removeTeamMember);

// Project Files
app.get('/api/projects/:id/files', authenticateToken, ProjectFileController.index);
app.post('/api/projects/:id/files', authenticateToken, projectLock('id'), projectFileUploadMiddleware, ProjectFileController.store);
app.delete('/api/projects/:id/files/:file', authenticateToken, projectLock('id'), ProjectFileController.destroy);

// Approvals
app.post('/api/projects/:project/accounting-approval', authenticateToken, projectApprovalController.accountingApproval);
app.post('/api/projects/:project/executive-approval', authenticateToken, projectApprovalController.executiveApproval);

// Inventory
app.get('/api/projects/:project/inventory', authenticateToken, projectInventoryController.index);
app.get('/api/projects/:project/inventory/history', authenticateToken, projectInventoryController.getProjectInventoryHistory);
app.get('/api/projects/:project/inventory/:item/history', authenticateToken, projectInventoryController.getItemHistory);
app.post('/api/projects/:project/inventory', authenticateToken, projectLock('project'), projectInventoryController.store);
app.put('/api/projects/:project/inventory/:item', authenticateToken, projectLock('project'), projectInventoryController.update);
app.patch('/api/projects/:project/inventory/:item/stock', authenticateToken, projectLock('project'), projectInventoryController.logTransaction);
app.delete('/api/projects/:project/inventory/:item', authenticateToken, projectLock('project'), projectInventoryController.destroy);

// Project Milestone Routes
app.get('/api/projects/:id/milestones', authenticateToken, projectController.getMilestones);
app.get('/api/projects/:id/milestone-plan', authenticateToken, projectController.getMilestonePlan);
app.post('/api/projects/:id/milestone-plan', authenticateToken, projectLock('id'), projectController.storeMilestonePlan);
app.get('/api/projects/:id/milestone-chart', authenticateToken, projectController.getMilestoneChart);
app.post('/api/projects/:id/milestone-submit', authenticateToken, projectLock('id'), projectController.submitMilestoneReview);

// Task Routes
app.get('/api/tasks/meta', authenticateToken, taskController.meta);
app.get('/api/tasks', authenticateToken, taskController.index);
app.post('/api/tasks', authenticateToken, uploadMiddleware, taskController.store);
app.get('/api/tasks/:task', authenticateToken, taskController.show);
app.put('/api/tasks/:task', authenticateToken, uploadMiddleware, taskController.update);
app.patch('/api/tasks/:task/status', authenticateToken, taskController.updateStatus);
app.delete('/api/tasks/:task', authenticateToken, taskController.destroy);

// Task Modules
app.get('/api/tasks/:task/comments', authenticateToken, taskCommentController.index);
app.post('/api/tasks/:task/comments', authenticateToken, taskCommentController.store);

app.get('/api/tasks/:task/attachments', authenticateToken, TaskAttachmentController.index);
app.post('/api/tasks/:task/attachments', authenticateToken, uploadMiddleware, TaskAttachmentController.store);
app.get('/api/tasks/:task/attachments/:attachment/download', authenticateToken, TaskAttachmentController.download);

app.get('/api/projects/:project/progress-logs', authenticateToken, TaskProgressLogController.index);
app.post('/api/task-progress-logs', authenticateToken, progressUploadMiddleware, TaskProgressLogController.store);
app.patch('/api/progress-logs/:id', authenticateToken, TaskProgressLogController.update);

// Report Routes
app.post('/api/reports/generate', authenticateToken, ReportController.generate);
app.post('/api/reports/export/pdf', authenticateToken, ReportController.exportPDF);
app.post('/api/reports/export/excel', authenticateToken, ReportController.exportExcel);

// Basic health check
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', environment: process.env.NODE_ENV || 'development' });
});

// Basic error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Internal server error', error: err.message });
});

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
// Nodemon trigger reload to Gmail SMTP
