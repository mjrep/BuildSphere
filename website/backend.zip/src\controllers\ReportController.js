const { createClient } = require('@supabase/supabase-js');
const MilestoneService = require('../services/MilestoneService');
const ReportExportService = require('../services/ReportExportService');

/**
 * ReportController - Handles complex construction report generation.
 */
class ReportController {
  
  static getSupabaseWithAuth(req) {
    const token = req.cookies?.['sb-access-token'];
    return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: `Bearer ${token}` } }
    });
  }

  /**
   * Generates a comprehensive project assessment report for one or more projects.
   * POST /api/reports/generate
   */
  static async generate(req, res) {
    try {
      const supabase = ReportController.getSupabaseWithAuth(req);
      const { 
        projectIds,
        startDate, 
        endDate, 
        includeProgress,
        includeInventory,
        includeAccomplishments
      } = req.body;

      if (!projectIds || !Array.isArray(projectIds)) {
        return res.status(400).json({ message: 'projectIds must be an array' });
      }

      const reportData = [];

      for (const id of projectIds) {
        let projectData = null;
        let progress = null;
        let inventory = [];
        let accomplishments = [];
        let completedTasks = [];

        const projectIdInt = parseInt(id);

        // 1. Fetch Project Details
        const { data: project, error: pError } = await supabase
          .from('projects')
          .select('*')
          .eq('id', projectIdInt)
          .single();
        
        if (pError) {
          console.error(`Error fetching project ${id}:`, pError);
          continue;
        }
        projectData = project;

        // 2. Fetch Progress/Milestones
        if (includeProgress) {
          try {
            const milestoneResult = await MilestoneService.getProjectMilestonesProgress(projectIdInt);
            progress = {
              phases: milestoneResult.phases,
              project_progress: milestoneResult.project_progress,
              schedule: 100 
            };
          } catch (e) {
            console.warn(`Progress fetch failed for project ${id}:`, e.message);
          }

          try {
            const { data: tasks, error: taskError } = await supabase
              .from('tasks')
              .select(`
                id,
                title,
                status,
                due_date,
                updated_at,
                milestone_id,
                assigned_to:users!assigned_to(first_name, last_name)
              `)
              .eq('project_id', projectIdInt);
            
            if (!taskError && tasks) {
              completedTasks = tasks.map(t => ({
                id: t.id,
                milestone_id: t.milestone_id,
                title: t.title,
                status: t.status,
                taken_by: t.assigned_to ? `${t.assigned_to.first_name} ${t.assigned_to.last_name}` : 'Field Staff',
                date: t.status === 'completed' 
                  ? (t.updated_at ? t.updated_at.split('T')[0] : (t.due_date ? t.due_date.split('T')[0] : 'N/A'))
                  : 'Ongoing'
              }));
            }
          } catch (e) {
            console.warn(`Tasks fetch failed for project ${id}:`, e.message);
          }
        }

        // 3. Fetch Inventory
        if (includeInventory) {
          try {
            const { data: invItems, error: invError } = await supabase
              .from('project_inventory_items')
              .select('*')
              .eq('project_id', projectIdInt);
            
            if (!invError && invItems) {
              const itemIds = invItems.map(item => item.id);
              
              let logsData = [];
              if (itemIds.length > 0) {
                const { data: invLogs } = await supabase
                  .from('project_inventory_logs')
                  .select('item_id, quantity')
                  .eq('action_type', 'RECEIVING')
                  .in('item_id', itemIds);
                if (invLogs) logsData = invLogs;
              }

              const receivedMap = {};
              logsData.forEach(log => {
                receivedMap[log.item_id] = (receivedMap[log.item_id] || 0) + parseFloat(log.quantity || 0);
              });

              inventory = invItems.map(item => {
                const totalReceived = receivedMap[item.id] || 0;
                // Fallback to current_stock if no RECEIVING logs exist (e.g. manual entry without logs)
                const purchasedQty = Math.max(totalReceived, parseFloat(item.current_stock || 0));
                const rawPrice = parseFloat(item.price) || 0;
                const totalValue = purchasedQty * rawPrice;

                return {
                  id: item.id,
                  item: item.item_name,
                  category: item.category || 'Material',
                  received: purchasedQty,
                  stock: item.current_stock || 0,
                  minStock: item.critical_level || 0,
                  price: item.price ? `₱${rawPrice.toLocaleString()}` : '₱0',
                  totalValue: totalValue,
                  totalValueDisplay: `₱${totalValue.toLocaleString()}`,
                  status: (parseFloat(item.current_stock || 0) <= parseFloat(item.critical_level || 0)) ? 'Low Stock' : 'In Stock'
                };
              });
            }
          } catch (e) {
            console.warn(`Inventory fetch failed for project ${id}:`, e.message);
          }
        }

        // 4. Fetch Accomplishments (Photos/Logs)
        if (includeAccomplishments) {
          try {
            // We fetch all logs and filter in JS to be absolutely sure of data integrity
            // matching the logic in TaskProgressLogController
            const { data: logs, error: logError } = await supabase
              .from('task_progress_logs')
              .select(`
                *,
                creator:users!created_by(id, first_name, last_name),
                task:tasks!task_id(id, title, assigned_to:users!assigned_to(first_name, last_name)),
                milestone:project_milestones!milestone_id(id, project_id, milestone_name)
              `)
              .not('evidence_image_path', 'is', null)
              .order('created_at', { ascending: false });
            
            if (!logError && logs) {
              // Filter by project_id in JS
              const projectLogs = logs.filter(l => l.milestone && l.milestone.project_id === projectIdInt);
              
              const bucket = process.env.SUPABASE_BUCKET_PROGRESS || 'site-progress';
              const supabaseUrl = process.env.SUPABASE_URL;

              accomplishments = projectLogs.map(log => {
                let imageUrl = null;
                if (log.evidence_image_path) {
                  imageUrl = log.evidence_image_path.startsWith('http') 
                    ? log.evidence_image_path 
                    : `${supabaseUrl}/storage/v1/object/public/${bucket}/${log.evidence_image_path.replace(/^\/+/, '')}`;
                }

                return {
                  id: log.id,
                  task_id: log.task?.id || null,
                  date: log.work_date || (log.created_at ? log.created_at.split('T')[0] : null),
                  time: log.created_at ? log.created_at.split('T')[1].substring(0, 5) : null,
                  shift: log.shift || (log.created_at ? (new Date(log.created_at).getHours() < 12 ? 'Morning' : new Date(log.created_at).getHours() < 17 ? 'Noon' : 'Afternoon') : 'Morning'),
                  title: log.task?.title || 'Site Update',
                  notes: log.remarks || log.notes || 'Progress update recorded.',
                  image_url: imageUrl,
                  taken_by: log.creator ? `${log.creator.first_name} ${log.creator.last_name}` : 'Field Staff',
                  quantity: log.quantity_accomplished,
                  milestone_name: log.milestone?.milestone_name
                };
              });
            } else if (logError) {
              console.error(`Accomplishments log error for project ${id}:`, logError);
            }
          } catch (e) {
            console.warn(`Accomplishments fetch failed for project ${id}:`, e.message);
          }
        }

        reportData.push({
          id: projectData.id,
          name: projectData.project_name,
          code: projectData.project_code,
          budget_for_materials: projectData.budget_for_materials,
          progress,
          inventory,
          accomplishments,
          completedTasks
        });
      }

      res.json({
        reportData,
        config: {
          startDate,
          endDate,
          includeProgress,
          includeInventory,
          includeAccomplishments
        }
      });

    } catch (error) {
      console.error('Report Generation Error:', error);
      res.status(500).json({ message: 'Internal server error during report compilation', error: error.message });
    }
  }

  /**
   * Exports compiled report data to PDF.
   * POST /api/reports/export/pdf
   */
  static async exportPDF(req, res) {
    try {
      const { reportData, config } = req.body;
      if (!reportData) return res.status(400).json({ message: 'Missing report data' });

      const payload = await ReportExportService.generatePDF(reportData, config);

      res.json(payload);
    } catch (error) {
      console.error('PDF Export Error:', error);
      res.status(500).json({ message: 'Failed to generate PDF', error: error.message });
    }
  }

  /**
   * Exports compiled report data to Excel.
   * POST /api/reports/export/excel
   */
  static async exportExcel(req, res) {
    try {
      const { reportData, config } = req.body;
      if (!reportData) return res.status(400).json({ message: 'Missing report data' });

      const excelBuffer = await ReportExportService.generateExcel(reportData, config);

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=BuildSphere_Report.xlsx');
      res.end(excelBuffer, 'binary');
    } catch (error) {
      console.error('Excel Export Error:', error);
      res.status(500).json({ message: 'Failed to generate Excel', error: error.message });
    }
  }
}

module.exports = ReportController;
