const { applyTaskVisibility, getAllVisibleProjectIds, getSalesProjectIds } = require('../utils/visibility');

class TaskQueryService {
  /**
   * Build a base query with all eager loads for list/kanban view, enforcing visibility.
   */
  static async applyBaseQuery(supabase, query, user) {
    const allVisibleProjectIds = await getAllVisibleProjectIds(supabase, user);
    let salesProjectIds = [];
    if (user.role === 'Sales') {
      salesProjectIds = await getSalesProjectIds(supabase, user.id);
    }

    // Add relation selections
    let baseQuery = query.select(`
      *,
      project:projects!inner(id, project_name, project_code, created_by, project_in_charge_id, project_user(user_id)),
      phase:project_phases(id, phase_key),
      milestone:project_milestones(id, milestone_name, has_quantity, target_quantity, current_quantity, unit_of_measure),
      assignedBy:users!assigned_by(id, first_name, last_name),
      assignedTo:users!assigned_to(id, first_name, last_name),
      creator:users!created_by(id, first_name, last_name)
    `, { count: 'exact' });

    // Enforce visibility using the shared utility
    baseQuery = applyTaskVisibility(baseQuery, user, allVisibleProjectIds, salesProjectIds);

    return { query: baseQuery };
  }

  /**
   * Apply all supported filters to a query builder.
   */
  static applyFilters(query, params) {
    let filteredQuery = query;

    if (params.search) {
      const term = params.search;
      // PostgREST doesn't easily support OR across joined tables in standard SDK queries, 
      // so we search title and description natively
      filteredQuery = filteredQuery.or(`title.ilike.%${term}%,description.ilike.%${term}%`);
    }

    if (params.project_id) {
      filteredQuery = filteredQuery.eq('project_id', params.project_id);
    }
    if (params.assigned_to) {
      filteredQuery = filteredQuery.eq('assigned_to', params.assigned_to);
    }
    if (params.created_by) {
      filteredQuery = filteredQuery.eq('created_by', params.created_by);
    }
    if (params.priority) {
      filteredQuery = filteredQuery.eq('priority', params.priority);
    }
    if (params.status) {
      filteredQuery = filteredQuery.eq('status', params.status.toLowerCase());
    }
    if (params.start_date) {
      filteredQuery = filteredQuery.gte('due_date', params.start_date);
    }
    if (params.end_date) {
      filteredQuery = filteredQuery.lte('due_date', params.end_date);
    }

    return filteredQuery;
  }

  /**
   * Apply sort order to a query.
   */
  static applySort(query, sortParam) {
    switch (sortParam) {
      case 'oldest':
        return query.order('created_at', { ascending: true });
      case 'due_date_asc':
        return query.order('due_date', { ascending: true });
      case 'due_date_desc':
        return query.order('due_date', { ascending: false });
      case 'priority_asc':
        // Supabase doesn't support custom CASE sorting out of the box in SDK, 
        // we fallback to alphabetical or rely on frontend sort for custom enums
        return query.order('priority', { ascending: true });
      case 'priority_desc':
        return query.order('priority', { ascending: false });
      case 'status':
        return query.order('status', { ascending: true });
      default:
        return query.order('created_at', { ascending: false }); // newest
    }
  }
}

module.exports = TaskQueryService;
