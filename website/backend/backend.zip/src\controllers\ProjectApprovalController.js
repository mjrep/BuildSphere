const { createClient } = require('@supabase/supabase-js');
const dotenv = require('dotenv');
const NotificationService = require('../services/NotificationService');

dotenv.config();

const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseKey = process.env.SUPABASE_ANON_KEY || '';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

class ProjectApprovalController {
  
  static getSupabaseWithAuth(req) {
    const token = req.cookies?.['sb-access-token'];
    return createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: `Bearer ${token}` } }
    });
  }

  static getSupabaseAdmin() {
    return createClient(supabaseUrl, supabaseServiceKey);
  }

  static async accountingApproval(req, res) {
    try {
      const user = req.user;
      const role = (user.role || '');
      
      // RBAC: Only Accounting role can approve budget
      if (role !== 'Accounting' && role !== 'Admin') {
        return res.status(403).json({ message: 'Unauthorized. Only Accounting can approve project budgets.' });
      }

      const supabaseAdmin = ProjectApprovalController.getSupabaseAdmin();
      const projectIdRaw = req.params.project; 
      const projectId = parseInt(projectIdRaw);
      const { decision, comments } = req.body;

      if (isNaN(projectId)) {
        return res.status(422).json({ 
          message: 'Invalid project ID format.', 
          received: projectIdRaw,
          hint: 'Check if the route parameter matches :project'
        });
      }

      if (!['APPROVED', 'REJECTED'].includes(decision)) {
        return res.status(422).json({ message: 'Invalid decision.' });
      }

      // 1. Fetch project to check status
      const { data: project, error: fetchError } = await supabaseAdmin
        .from('projects')
        .select('*')
        .eq('id', projectId)
        .single();
        
      if (fetchError || !project) {
        return res.status(404).json({ 
          message: 'Project not found', 
          error: fetchError?.message,
          queried_id: projectId 
        });
      }

      const subStatus = (project.sub_status || '').toLowerCase();
      if ((subStatus !== 'pending_approval' && subStatus !== 'for_accounting_approval') || project.accounting_approved_at !== null) {
        return res.status(422).json({ 
          message: 'This project is not pending accounting approval.',
          current_sub_status: project.sub_status,
          approved_at: project.accounting_approved_at
        });
      }

      // 2. Perform updates
      const updates = {};
      let actionName = '';
      let desc = '';
      const oldStatus = project.status;
      const oldSubStatus = project.sub_status;
      let newStatus = project.status;
      let newSubStatus = null;
      
      if (decision === 'APPROVED') {
        newSubStatus = 'for_executives_approval';
        updates.sub_status = newSubStatus;
        updates.accounting_approved_by = user.id;
        updates.accounting_approved_at = new Date().toISOString();
        actionName = 'ACCOUNTING_APPROVED';
        desc = 'Accounting approved the project. Now pending executive approval.';
      } else {
        newSubStatus = 'for_revision';
        updates.sub_status = newSubStatus;
        updates.rejected_by = user.id;
        updates.rejection_reason = comments;
        actionName = 'ACCOUNTING_REJECTED';
        desc = `Accounting rejected: ${comments}`;
      }

      const { data: updatedProject, error: updateError } = await supabaseAdmin
        .from('projects')
        .update(updates)
        .eq('id', projectId)
        .select()
        .single();

      if (updateError) {
        return res.status(500).json({ message: 'Update failed', error: updateError.message });
      }

      // 3. Log Records
      try {
        await supabaseAdmin.from('project_approvals').insert([{
          project_id: projectId,
          approval_stage: 'ACCOUNTING',
          approver_user_id: user.id,
          decision,
          comments: comments || '',
          decided_at: new Date().toISOString()
        }]);

        await supabaseAdmin.from('project_activity_logs').insert([{
          project_id: projectId,
          user_id: user.id,
          action: actionName,
          description: desc
        }]);

        await supabaseAdmin.from('project_revisions').insert([{
          project_id: projectId,
          from_status: `${oldStatus}:${oldSubStatus}`,
          to_status: `${newStatus}:${newSubStatus}`,
          requested_by: user.id,
          comments: comments || ''
        }]);

        if (decision === 'APPROVED') {
          // Send notification to Executives
          try {
            const { data: execUsers } = await supabaseAdmin
              .from('users')
              .select('id')
              .in('role', ['CEO', 'COO']);

            if (execUsers && execUsers.length > 0) {
              for (const exec of execUsers) {
                await NotificationService.createNotification(
                  exec.id,
                  'Project For Executive Approval',
                  `Project '${project.project_name || 'Unnamed'}' has been approved by Accounting and is now awaiting your approval.`,
                  'info',
                  `/projects/${projectId}`
                );
              }
            }
          } catch (notifErr) {
            console.error('Executive Approval Notification Error:', notifErr);
          }
        }
      } catch (logError) {
        console.error('Logging records failed:', logError);
      }

      res.json({ data: updatedProject });
    } catch (err) {
      console.error('Accounting Approval Error:', err);
      res.status(500).json({ message: err.message || 'Error processing accounting approval' });
    }
  }

  static async executiveApproval(req, res) {
    try {
      const user = req.user;
      const role = (user.role || '');

      // RBAC: Only CEO or COO can give final approval
      if (!['CEO', 'COO', 'Admin'].includes(role)) {
        return res.status(403).json({ message: 'Unauthorized. Only CEO or COO can provide executive approval.' });
      }

      const supabaseAdmin = ProjectApprovalController.getSupabaseAdmin();
      const projectIdRaw = req.params.project; 
      const projectId = parseInt(projectIdRaw);
      const { decision, comments } = req.body;

      if (isNaN(projectId)) {
        return res.status(422).json({ 
          message: 'Invalid project ID format.', 
          received: projectIdRaw,
          hint: 'Check if the route parameter matches :project'
        });
      }

      if (!['APPROVED', 'REJECTED'].includes(decision)) {
        return res.status(422).json({ message: 'Invalid decision.' });
      }

      // 1. Fetch project to check status
      const { data: project, error: fetchError } = await supabaseAdmin
        .from('projects')
        .select('*')
        .eq('id', projectId)
        .single();
        
      if (fetchError || !project) {
        return res.status(404).json({ 
          message: 'Project not found', 
          error: fetchError?.message,
          queried_id: projectId 
        });
      }

      const subStatus = (project.sub_status || '').toLowerCase();
      if ((subStatus !== 'pending_approval' && subStatus !== 'for_executives_approval') || project.accounting_approved_at === null) {
        return res.status(422).json({ 
          message: 'This project is not pending executive approval.',
          current_sub_status: project.sub_status,
          accounting_approved_at: project.accounting_approved_at
        });
      }

      // 2. Perform updates
      const updates = {};
      let actionName = '';
      let desc = '';
      const oldStatus = project.status;
      const oldSubStatus = project.sub_status;
      let newStatus = project.status;
      let newSubStatus = null;
      
      if (decision === 'APPROVED') {
        newStatus = 'ongoing';
        newSubStatus = null;
        updates.status = newStatus;
        updates.sub_status = newSubStatus;
        updates.executive_approved_by = user.id;
        updates.executive_approved_at = new Date().toISOString();
        actionName = 'EXECUTIVE_APPROVED';
        desc = 'Executive approved the project. Project is now ongoing.';
      } else {
        newSubStatus = 'for_revision';
        updates.sub_status = newSubStatus;
        updates.rejected_by = user.id;
        updates.rejection_reason = comments;
        actionName = 'EXECUTIVE_REJECTED';
        desc = `Executive rejected: ${comments}`;
      }

      const { data: updatedProject, error: updateError } = await supabaseAdmin
        .from('projects')
        .update(updates)
        .eq('id', projectId)
        .select()
        .single();

      if (updateError) {
        return res.status(500).json({ message: 'Update failed', error: updateError.message });
      }

      // 3. Log Records
      try {
        await supabaseAdmin.from('project_approvals').insert([{
          project_id: projectId,
          approval_stage: 'EXECUTIVE',
          approver_user_id: user.id,
          decision,
          comments: comments || '',
          decided_at: new Date().toISOString()
        }]);

        await supabaseAdmin.from('project_activity_logs').insert([{
          project_id: projectId,
          user_id: user.id,
          action: actionName,
          description: desc
        }]);

        await supabaseAdmin.from('project_revisions').insert([{
          project_id: projectId,
          from_status: `${oldStatus}:${oldSubStatus}`,
          to_status: `${newStatus}${newSubStatus ? ':' + newSubStatus : ''}`,
          requested_by: user.id,
          comments: comments || ''
        }]);

        // Notify Accounting of the Executive's final decision
        try {
          const { data: accountingUsers } = await supabaseAdmin
            .from('users')
            .select('id')
            .ilike('role', '%accounting%');

          if (accountingUsers && accountingUsers.length > 0) {
            for (const accUser of accountingUsers) {
              await NotificationService.createNotification(
                accUser.id,
                decision === 'APPROVED' ? 'Project Fully Approved' : 'Project Rejected by Executive',
                decision === 'APPROVED' 
                  ? `Project '${project.project_name || 'Unnamed'}' has been fully approved by Executives and is now ongoing.`
                  : `Project '${project.project_name || 'Unnamed'}' was rejected by Executives: ${comments}`,
                decision === 'APPROVED' ? 'success' : 'error',
                `/projects/${projectId}`
              );
            }
          }
        } catch (notifErr) {
          console.error('Accounting Executive Decision Notification Error:', notifErr);
        }
      } catch (logError) {
        console.error('Logging records failed:', logError);
      }

      res.json({ data: updatedProject });
    } catch (err) {
      console.error('Executive Approval Error:', err);
      res.status(500).json({ message: err.message || 'Error processing executive approval' });
    }
  }
}

module.exports = ProjectApprovalController;
